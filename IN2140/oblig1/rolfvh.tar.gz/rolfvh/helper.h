int getstrlen(char* s);
